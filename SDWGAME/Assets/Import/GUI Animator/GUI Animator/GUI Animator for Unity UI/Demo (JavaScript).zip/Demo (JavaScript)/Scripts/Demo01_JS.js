// GUI Animator for Unity UI
// Version: 1.1.5
// Compatilble: Unity 5.5.1 or higher, more info in Readme.txt file.
//
// Developer:				Gold Experience Team (https://www.assetstore.unity3d.com/en/#!/search/page=1/sortby=popularity/query=publisher:4162)
// Unity Asset Store:		https://www.assetstore.unity3d.com/en/#!/content/28709
//
// Please direct any bugs/comments/suggestions to geteamdev@gmail.com.

// ######################################################################
// Demo01_JS class
// - Animates all GAui elements in the scene.
// - Responds to user mouse click or tap on buttons.
//
// Note this class is attached with "-SceneController-" object in "GA UUI JS - Demo01 (960x600px)" scene.
// ######################################################################

class Demo01_JS extends MonoBehaviour {

	// ########################################
	// Variables
	// ########################################

    // Canvas
    var m_Canvas : Canvas;

   // GUIAnim objects of title text
    var m_Title1 : GAui;
    var m_Title2 : GAui;
	
   // GUIAnim objects of top and bottom bars
    var m_TopBar : GAui;
    var m_BottomBar : GAui;
	
   // GUIAnim objects of TopLeft buttons
    var m_TopLeft_A : GAui;
    var m_TopLeft_B : GAui;
	
   // GUIAnim objects of BottomLeft buttons
    var m_BottomLeft_A : GAui;
    var m_BottomLeft_B : GAui;
	
   // GUIAnim objects of RightBar buttons
    var m_RightBar_A : GAui;
    var m_RightBar_B : GAui;
    var m_RightBar_C : GAui;

   // Toggle state of TopLeft, BottomLeft and BottomLeft buttons
    protected var m_TopLeft_IsOn : boolean= false;
    protected var m_BottomLeft_IsOn : boolean= false;
    protected var m_RightBar_IsOn : boolean= false;
	
	// ########################################
	// MonoBehaviour Functions
	// http://docs.unity3d.com/ScriptReference/MonoBehaviour.html
	// ########################################
		
	// Awake is called when the script instance is being loaded.
	// http://docs.unity3d.com/ScriptReference/MonoBehaviour.Awake.html
   function Awake () {
       
	if(enabled)
       {
           // Set GSui.Instance.m_AutoAnimation to false in Awake(), let you control all GUI Animator elements in the scene via scripts.
           GSui.Instance.m_AutoAnimation = false;
       }
   }

	// Start is called on the frame when a script is enabled just before any of the Update methods is called the first time.
	// http://docs.unity3d.com/ScriptReference/MonoBehaviour.Start.html
        function Start () {
	
            // MoveIn m_TopBar and m_BottomBar
            m_TopBar.MoveIn(GSui.eGUIMove.SelfAndChildren);
            m_BottomBar.MoveIn(GSui.eGUIMove.SelfAndChildren);

            // MoveIn m_Title1 and m_Title2
            StartCoroutine(MoveInTitleGameObjects());

            // Disable all scene switch buttons
		// http://docs.unity3d.com/Manual/script-GraphicRaycaster.html
            GSui.Instance.SetGraphicRaycasterEnable(m_Canvas, false);

        }
	
	// Update is called every frame, if the MonoBehaviour is enabled.
	// http://docs.unity3d.com/ScriptReference/MonoBehaviour.Update.html
        function Update () {
		
        }
	
	// ########################################
	// MoveIn/MoveOut functions
	// ########################################
	
        // MoveIn m_Title1 and m_Title2
        function MoveInTitleGameObjects () : IEnumerator {
            yield WaitForSeconds(1.0f);

            // MoveIn m_Title1 and m_Title2
            m_Title1.MoveIn(GSui.eGUIMove.Self);
            m_Title2.MoveIn(GSui.eGUIMove.Self);
		
            // MoveIn all primary buttons
            StartCoroutine(MoveInPrimaryButtons());
        }
	
            // MoveIn all primary buttons
            function MoveInPrimaryButtons () : IEnumerator {
                yield  WaitForSeconds(1.0f);

                // MoveIn all primary buttons
                m_TopLeft_A.MoveIn(GSui.eGUIMove.Self);
                m_BottomLeft_A.MoveIn(GSui.eGUIMove.Self);
                m_RightBar_A.MoveIn(GSui.eGUIMove.Self);

                // Enable all scene switch buttons
                StartCoroutine(EnableAllDemoButtons());
            }

                // MoveOut all primary buttons
                function HideAllGUIs () {
                    m_TopLeft_A.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    m_BottomLeft_A.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    m_RightBar_A.MoveOut(GSui.eGUIMove.Self);
		
                    if(m_TopLeft_IsOn == true)
                        m_TopLeft_B.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    if(m_BottomLeft_IsOn == true)
                        m_BottomLeft_B.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    if(m_RightBar_IsOn == true)
                        m_RightBar_B.MoveOut(GSui.eGUIMove.SelfAndChildren);
		
                    // MoveOut m_Title1 and m_Title2
                    StartCoroutine(HideTitleTextMeshes());
                }
	
                // MoveOut m_Title1 and m_Title2
                function HideTitleTextMeshes () : IEnumerator {
                    yield  WaitForSeconds(1.0f);

                    // MoveOut m_Title1 and m_Title2
                    m_Title1.MoveOut(GSui.eGUIMove.Self);
                    m_Title2.MoveOut(GSui.eGUIMove.Self);
		
                    // MoveOut m_TopBar and m_BottomBar
                    m_TopBar.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    m_BottomBar.MoveOut(GSui.eGUIMove.SelfAndChildren);
                }
		
                    // ######################################################################
                    // Enable/Disable button functions
                    // ######################################################################
	
                    // Enable/Disable all scene switch Coroutine
                    function EnableAllDemoButtons () : IEnumerator {
                        yield  WaitForSeconds(1.0f);
		
                        // Enable all scene switch buttons
		// http://docs.unity3d.com/Manual/script-GraphicRaycaster.html
                        GSui.Instance.SetGraphicRaycasterEnable(m_Canvas, true);
                    }
	
                        // Disable all buttons for a few seconds
                        function DisableButtonForSeconds ( GO : GameObject ,   DisableTime : float  ) : IEnumerator {
                            // Disable all buttons
                            GSui.Instance.EnableButton(GO.transform, false);
		
                            yield  WaitForSeconds(DisableTime);
		
                            // Enable all buttons
                            GSui.Instance.EnableButton(GO.transform, true);
                        }
		
	// ########################################
	// UI Responder functions
	// ########################################
	
                            function OnButton_TopLeft () {
                                // Disable m_TopLeft_A, m_RightBar_A, m_RightBar_C, m_BottomLeft_A for a few seconds
                                StartCoroutine(DisableButtonForSeconds(m_TopLeft_A.gameObject, 0.3f));
                                StartCoroutine(DisableButtonForSeconds(m_RightBar_A.gameObject, 0.6f));
                                StartCoroutine(DisableButtonForSeconds(m_RightBar_C.gameObject, 0.6f));
                                StartCoroutine(DisableButtonForSeconds(m_BottomLeft_A.gameObject, 0.3f));

                                // Toggle m_TopLeft
                                ToggleTopLeft();

                                // Toggle other buttons
                                if(m_BottomLeft_IsOn==true)
                                {
                                    ToggleBottomLeft();
                                }
                                if(m_RightBar_IsOn==true)
                                {
                                    ToggleRightBar();
                                }
                            }

                            function OnButton_BottomLeft () {
                                // Disable m_TopLeft_A, m_RightBar_A, m_RightBar_C, m_BottomLeft_A for a few seconds
                                StartCoroutine(DisableButtonForSeconds(m_TopLeft_A.gameObject, 0.3f));
                                StartCoroutine(DisableButtonForSeconds(m_RightBar_A.gameObject, 0.6f));
                                StartCoroutine(DisableButtonForSeconds(m_RightBar_C.gameObject, 0.6f));
                                StartCoroutine(DisableButtonForSeconds(m_BottomLeft_A.gameObject, 0.3f));

                                // Toggle m_BottomLeft
                                ToggleBottomLeft();
		
                                // Toggle other buttons
                                if(m_TopLeft_IsOn==true)
                                {
                                    ToggleTopLeft();
                                }
                                if(m_RightBar_IsOn==true)
                                {
                                    ToggleRightBar();
                                }
		
                            }
	
                            function OnButton_RightBar () {
                                // Disable m_TopLeft_A, m_RightBar_A, m_RightBar_C, m_BottomLeft_A for a few seconds
                                StartCoroutine(DisableButtonForSeconds(m_TopLeft_A.gameObject, 0.3f));
                                StartCoroutine(DisableButtonForSeconds(m_RightBar_A.gameObject, 0.6f));
                                StartCoroutine(DisableButtonForSeconds(m_RightBar_C.gameObject, 0.6f));
                                StartCoroutine(DisableButtonForSeconds(m_BottomLeft_A.gameObject, 0.3f));

                                // Toggle m_RightBar
                                ToggleRightBar();
		
                                // Toggle other buttons
                                if(m_TopLeft_IsOn==true)
                                {
                                    ToggleTopLeft();
                                }
                                if(m_BottomLeft_IsOn==true)
                                {
                                    ToggleBottomLeft();
                                }

                            }
		
	// ########################################
	// Toggle button functions
	// ########################################
	
                            // Toggle TopLeft buttons
                            function ToggleTopLeft () {
                                m_TopLeft_IsOn = !m_TopLeft_IsOn;
                                if(m_TopLeft_IsOn==true)
                                {
                                    // m_TopLeft_B moves in
                                    m_TopLeft_B.MoveIn(GSui.eGUIMove.SelfAndChildren);
                                }
                                else
                                {
                                    // m_TopLeft_B moves out
                                    m_TopLeft_B.MoveOut(GSui.eGUIMove.SelfAndChildren);
                                }
                            }
	
                            // Toggle BottomLeft buttons
                            function ToggleBottomLeft () {
                                m_BottomLeft_IsOn = !m_BottomLeft_IsOn;
                                if(m_BottomLeft_IsOn==true)
                                {
                                    // m_BottomLeft_B moves in
                                    m_BottomLeft_B.MoveIn(GSui.eGUIMove.SelfAndChildren);
                                }
                                else
                                {
                                    // m_BottomLeft_B moves out
                                    m_BottomLeft_B.MoveOut(GSui.eGUIMove.SelfAndChildren);
                                }
                            }
	
                            // Toggle RightBar buttons
                            function ToggleRightBar () {
                                m_RightBar_IsOn = !m_RightBar_IsOn;
                                if(m_RightBar_IsOn==true)
                                {
                                    // m_RightBar_A moves out
                                    m_RightBar_A.MoveOut(GSui.eGUIMove.SelfAndChildren);
                                    // m_RightBar_B moves in
                                    m_RightBar_B.MoveIn(GSui.eGUIMove.SelfAndChildren);
                                }
                                else
                                {
                                    // m_RightBar_A moves in
                                    m_RightBar_A.MoveIn(GSui.eGUIMove.SelfAndChildren);
                                    // m_RightBar_B moves out
                                    m_RightBar_B.MoveOut(GSui.eGUIMove.SelfAndChildren);
                                }
                            }
                        }